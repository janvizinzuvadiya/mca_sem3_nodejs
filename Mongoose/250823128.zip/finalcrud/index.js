import express from "express";
import db from "./db.js"

const app=express();

app.use(express.json())

app.get("/book",(req,res)=>{
    db.query("select * from book",(err,results)=>{
        if(err){
           res.json({message:"fail",data:err.message})
        }
        else{
           res.json({message:"success",data:results})
        }
    })
   
});
app.post("/book/store",(req,res)=>{
    db.query("insert into book set ?",req.body,(err,results)=>{
        if(err){
           res.json({message:"fail",data:err.message})
        }
        else{
           res.json({message:"success",data:results.insertId})
        }
    })
   
});
app.put("/book/edit/:id",(req,res)=>{
    const id=req.params.id;
    db.query("update book set ? where id=?",[req.body,id],(err,results)=>{
        if(err){
           res.json({message:"fail",data:err.message})
        }
        else{
           res.json({message:"success",data:results.affectedRows})
        }
    })
   
});
app.delete("/book/delete/:id",(req,res)=>{
    const id=req.params.id;
    db.query("delete from book where id=?",[id],(err,results)=>{
        if(err){
           res.json({message:"fail",data:err.message})
        }
        else{
           res.json({message:"success",data:results.affectedRows})
        }
    })
   
});
app.listen(3000,(req,res)=>{
   console.log(`server run on http://localhost:3000`)
})