import mysql from "mysql2";

const db=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"book1"
});
export default db;